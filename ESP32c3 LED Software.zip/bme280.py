# bmp280.py — Minimal MicroPython driver for BMP280
# Provides temperature (°C), pressure (Pa/hPa), and altitude estimate.
# Works without adafruit_bus_device or extra libs.

import time
from ustruct import unpack_from

# Registers
_REG_CALIB     = 0x88
_REG_STATUS    = 0xF3
_REG_CTRL_MEAS = 0xF4
_REG_CONFIG    = 0xF5
_REG_PRESS_MSB = 0xF7  # through 0xFC (6 bytes)

# Modes
_SLEEP  = 0x00
_FORCED = 0x01
_NORMAL = 0x03

class BMP280:
    def __init__(self, i2c, addr=0x76, osrs_t=1, osrs_p=1, filt=0, mode='forced'):
        self.i2c = i2c
        self.addr = addr
        self._t_fine = 0

        # Read calibration
        calib = bytearray(24)
        self.i2c.readfrom_mem_into(self.addr, _REG_CALIB, calib)
        self.dig_T1 = unpack_from("<H", calib, 0)[0]
        self.dig_T2 = unpack_from("<h", calib, 2)[0]
        self.dig_T3 = unpack_from("<h", calib, 4)[0]
        self.dig_P1 = unpack_from("<H", calib, 6)[0]
        self.dig_P2 = unpack_from("<h", calib, 8)[0]
        self.dig_P3 = unpack_from("<h", calib, 10)[0]
        self.dig_P4 = unpack_from("<h", calib, 12)[0]
        self.dig_P5 = unpack_from("<h", calib, 14)[0]
        self.dig_P6 = unpack_from("<h", calib, 16)[0]
        self.dig_P7 = unpack_from("<h", calib, 18)[0]
        self.dig_P8 = unpack_from("<h", calib, 20)[0]
        self.dig_P9 = unpack_from("<h", calib, 22)[0]

        # Configure filter (filt << 2)
        self.i2c.writeto_mem(self.addr, _REG_CONFIG, bytes([(filt & 0x07) << 2]))

        # Oversampling + mode
        self._osrs_t = osrs_t & 0x07
        self._osrs_p = osrs_p & 0x07
        self._mode   = _FORCED if mode == 'forced' else _NORMAL
        self._update_ctrl_meas()

    def _update_ctrl_meas(self, mode=None):
        if mode is None:
            mode = self._mode
        ctrl = (self._osrs_t << 5) | (self._osrs_p << 2) | (mode & 0x03)
        self.i2c.writeto_mem(self.addr, _REG_CTRL_MEAS, bytes([ctrl]))

    def _is_measuring(self):
        return bool(self.i2c.readfrom_mem(self.addr, _REG_STATUS, 1)[0] & 0x08)

    def _raw_values(self):
        if self._mode == _FORCED:
            self._update_ctrl_meas(mode=_FORCED)
            t0 = time.ticks_ms()
            while self._is_measuring():
                if time.ticks_diff(time.ticks_ms(), t0) > 100:
                    break
                time.sleep_ms(2)
        data = self.i2c.readfrom_mem(self.addr, _REG_PRESS_MSB, 6)
        adc_P = ((data[0] << 12) | (data[1] << 4) | (data[2] >> 4)) & 0xFFFFF
        adc_T = ((data[3] << 12) | (data[4] << 4) | (data[5] >> 4)) & 0xFFFFF
        return adc_T, adc_P

    # Compensation from datasheet
    def _compensate_temp(self, adc_T):
        var1 = (adc_T / 16384.0 - self.dig_T1 / 1024.0) * self.dig_T2
        var2 = ((adc_T / 131072.0 - self.dig_T1 / 8192.0) *
                (adc_T / 131072.0 - self.dig_T1 / 8192.0)) * self.dig_T3
        self._t_fine = int(var1 + var2)
        return (var1 + var2) / 5120.0

    def _compensate_press(self, adc_P):
        var1 = self._t_fine / 2.0 - 64000.0
        var2 = var1 * var1 * self.dig_P6 / 32768.0
        var2 += var1 * self.dig_P5 * 2.0
        var2 = var2 / 4.0 + self.dig_P4 * 65536.0
        var1 = (self.dig_P3 * var1 * var1 / 524288.0 + self.dig_P2 * var1) / 524288.0
        var1 = (1.0 + var1 / 32768.0) * self.dig_P1
        if var1 == 0:
            return 0
        p = 1048576.0 - adc_P
        p = (p - var2 / 4096.0) * 6250.0 / var1
        var1 = self.dig_P9 * p * p / 2147483648.0
        var2 = p * self.dig_P8 / 32768.0
        p = p + (var1 + var2 + self.dig_P7) / 16.0
        return p

    # Public API
    def read(self):
        adc_T, adc_P = self._raw_values()
        t = self._compensate_temp(adc_T)
        p = self._compensate_press(adc_P)
        return t, p

    @property
    def temperature(self):
        t, _ = self.read()
        return t

    @property
    def pressure(self):
        _, p = self.read()
        return p  # Pa

    def pressure_hpa(self):
        return self.pressure / 100.0

    def altitude(self, sea_level_hpa=1013.25):
        p = self.pressure / 100.0
        return 44330.0 * (1.0 - (p / sea_level_hpa) ** (1/5.255))
