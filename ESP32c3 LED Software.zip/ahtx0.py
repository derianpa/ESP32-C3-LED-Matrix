# ahtx0.py - Simple MicroPython driver for AHT20/AHT21/AHT10
# Save this file to your board as ahtx0.py

import time

class AHT20:
    def __init__(self, i2c, addr=0x38):
        self.i2c = i2c
        self.addr = addr
        # Init sequence
        self.i2c.writeto(self.addr, b'\xBE\x08\x00')
        time.sleep_ms(40)

    def _trigger_measurement(self):
        self.i2c.writeto(self.addr, b'\xAC\x33\x00')
        time.sleep_ms(80)

    def _read_raw(self):
        self._trigger_measurement()
        data = bytearray(6)
        self.i2c.readfrom_into(self.addr, data)
        return data

    @property
    def temperature(self):
        data = self._read_raw()
        t_raw = ((data[3] & 0x0F) << 16) | (data[4] << 8) | data[5]
        return ((t_raw * 200) / 1048576) - 50

    @property
    def relative_humidity(self):
        data = self._read_raw()
        h_raw = ((data[1] << 16) | (data[2] << 8) | data[3]) >> 4
        return (h_raw * 100) / 1048576
