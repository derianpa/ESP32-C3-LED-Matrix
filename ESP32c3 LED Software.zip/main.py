import network, socket, time, urandom, math, _thread, ujson, os, gc
import ntptime
from machine import Pin, I2C
from time import sleep
import neopixel
import ssd1306

# =========================
# OLED Setup (64x40) + full hardware clear (as you had it)
# =========================
i2c = I2C(0, scl=Pin(6), sda=Pin(5))
oled = ssd1306.SSD1306_I2C(64, 40, i2c)

def full_hardware_clear(i2c, addr=0x3C):
    temp = bytearray(2)
    write_list = [b"\x40", None]
    blank = bytearray([0x00] * 128)

    # Set column and page address range
    i2c.writeto(addr, bytes([0x00, 0x21]))  # Set column address
    i2c.writeto(addr, bytes([0x00, 0]))     # Start at 0
    i2c.writeto(addr, bytes([0x00, 127]))   # End at 127

    i2c.writeto(addr, bytes([0x00, 0x22]))  # Set page address
    i2c.writeto(addr, bytes([0x00, 0]))     # Page 0
    i2c.writeto(addr, bytes([0x00, 7]))     # Page 7 (8×8 = 64 rows)

    for _ in range(8):  # Write 8 blank pages
        write_list[1] = blank
        i2c.writevto(addr, write_list)

# clear OLED RAM once at boot
full_hardware_clear(i2c)

# helper to write up to 4 lines on 64x40
def oled_msg(line1="", line2="", line3="", line4=""):
    oled.fill(0)
    if line1: oled.text(line1, 0, 0)
    if line2: oled.text(line2, 0, 10)
    if line3: oled.text(line3, 0, 20)
    if line4: oled.text(line4, 0, 30)
    oled.show()

def rate_signal(rssi):
    if rssi is None:
        return "X"
    if rssi >= -50:
        return "*****"
    elif rssi >= -60:
        return "****"
    elif rssi >= -70:
        return "***"
    elif rssi >= -80:
        return "**"
    elif rssi >= -90:
        return "*"
    else:
        return "X"

def format_ip_three_lines(ip):
    ip = str(ip)
    parts = ip.split(".")
    if len(parts) == 4:
        a, b, c, d = parts
        line2 = "{}.{}.".format(a, b)
        rest = "{}.{}".format(c, d)
        if len(rest) <= 11:
            line3 = rest
            line4 = ""
        else:
            line3 = rest[:11]
            line4 = rest[11:22]
        return line2, line3, line4

    if len(ip) <= 11:
        return ip, "", ""
    line2 = ip[:11]
    rem = ip[11:]
    if len(rem) <= 11:
        return line2, rem, ""
    line3 = rem[:11]
    line4 = rem[11:22]
    return line2, line3, line4

# =========================
# LED Matrix Setup (ESP32-C3)
# =========================
PIN_NUM = 2
WIDTH = 8
HEIGHT = 8
NUM = WIDTH * HEIGHT
BRIGHTNESS = 0.20
SCROLL_SPEED = 0.12

np = neopixel.NeoPixel(Pin(PIN_NUM, Pin.OUT), NUM)

def scale(color):
    r,g,b = color
    return (int(r*BRIGHTNESS), int(g*BRIGHTNESS), int(b*BRIGHTNESS))

# 90° clockwise rotated XY, serpentine rows
def XY(x, y):
    new_x = y
    new_y = (HEIGHT - 1) - x
    if new_y % 2 == 0:
        return new_y * WIDTH + new_x
    else:
        return new_y * WIDTH + (WIDTH - 1 - new_x)

def clear():
    np.fill((0,0,0)); np.write()

def set_pixel(x,y,c):
    if 0<=x<WIDTH and 0<=y<HEIGHT:
        np[XY(x,y)] = scale(c)

def random_color():
    return (urandom.getrandbits(8), urandom.getrandbits(8), urandom.getrandbits(8))

# =========================
# Software framebuffer
# =========================
fb = [[(0,0,0) for _ in range(WIDTH)] for __ in range(HEIGHT)]

def fb_clear():
    for y in range(HEIGHT):
        for x in range(WIDTH):
            fb[y][x] = (0,0,0)

def fb_fill(c):
    for y in range(HEIGHT):
        for x in range(WIDTH):
            fb[y][x] = c

def fb_set(x,y,c):
    if 0<=x<WIDTH and 0<=y<HEIGHT:
        fb[y][x] = c

def fb_fade(f):
    for y in range(HEIGHT):
        row = fb[y]
        for x in range(WIDTH):
            r,g,b = row[x]
            row[x] = (int(r*f), int(g*f), int(b*f))

def fb_render():
    for y in range(HEIGHT):
        for x in range(WIDTH):
            np[XY(x,y)] = scale(fb[y][x])
    np.write()

# =========================
# Font (your full set)
# =========================
FONT_8x8 = {
    "A":["00111000","01000100","01000100","01111100","01000100","01000100","01000100","01000100"],
    "B":["01111000","01000100","01000100","01111000","01000100","01000100","01000100","01111000"],
    "C":["00111100","01000000","01000000","01000000","01000000","01000000","01000000","00111100"],
    "D":["01111000","01000100","01000100","01000100","01000100","01000100","01000100","01111000"],
    "E":["01111100","01000000","01000000","01111000","01000000","01000000","01000000","01111100"],
    "F":["01111100","01000000","01000000","01111000","01000000","01000000","01000000","01000000"],
    "G":["00111100","01000000","01000000","01000000","01001100","01000100","01000100","00111000"],
    "H":["01000100","01000100","01000100","01111100","01000100","01000100","01000100","01000100"],
    "I":["00111000","00010000","00010000","00010000","00010000","00010000","00010000","00111000"],
    "J":["00011100","00001000","00001000","00001000","00001000","01001000","01001000","00110000"],
    "K":["01000100","01001000","01010000","01100000","01010000","01001000","01000100","01000100"],
    "L":["01000000","01000000","01000000","01000000","01000000","01000000","01000000","01111100"],
    "M":["01000100","01101100","01010100","01000100","01000100","01000100","01000100","01000100"],
    "N":["01000100","01100100","01010100","01001100","01000100","01000100","01000100","01000100"],
    "O":["00111000","01000100","01000100","01000100","01000100","01000100","01000100","00111000"],
    "P":["01111000","01000100","01000100","01111000","01000000","01000000","01000000","01000000"],
    "Q":["00111000","01000100","01000100","01000100","01000100","01010100","01001100","00111010"],
    "R":["01111000","01000100","01000100","01111000","01010000","01001000","01000100","01000100"],
    "S":["00111100","01000000","01000000","00111000","00000100","00000100","01000100","00111000"],
    "T":["01111100","00010000","00010000","00010000","00010000","00010000","00010000","00010000"],
    "U":["01000100","01000100","01000100","01000100","01000100","01000100","01000100","00111000"],
    "V":["01000100","01000100","01000100","01000100","01000100","00101000","00101000","00010000"],
    "W":["01000100","01000100","01000100","01000100","01010100","01101100","01000100","01000100"],
    "X":["01000100","00101000","00010000","00010000","00010000","00101000","01000100","01000100"],
    "Y":["01000100","00101000","00010000","00010000","00010000","00010000","00010000","00010000"],
    "Z":["01111100","00000100","00001000","00010000","00100000","01000000","01000000","01111100"],
    "0":["00111000","01000100","01001100","01010100","01100100","01000100","01000100","00111000"],
    "1":["00010000","00110000","00010000","00010000","00010000","00010000","00010000","00111000"],
    "2":["00111000","01000100","00000100","00001000","00010000","00100000","01000000","01111100"],
    "3":["00111000","01000100","00000100","00011000","00000100","00000100","01000100","00111000"],
    "4":["00001000","00011000","00101000","01001000","01111100","00001000","00001000","00001000"],
    "5":["01111100","01000000","01111000","00000100","00000100","00000100","01000100","00111000"],
    "6":["00111000","01000000","01111000","01000100","01000100","01000100","01000100","00111000"],
    "7":["01111100","00000100","00001000","00010000","00100000","01000000","01000000","01000000"],
    "8":["00111000","01000100","01000100","00111000","01000100","01000100","01000100","00111000"],
    "9":["00111000","01000100","01000100","00111100","00000100","00000100","00000100","00111000"],
    ":":["00000000","00000000","00011000","00011000","00000000","00011000","00011000","00000000"],
    ".":["00000000","00000000","00000000","00000000","00000000","00000000","00011000","00011000"],
    ",":["00000000","00000000","00000000","00000000","00000000","00011000","00011000","00001000"],
    " ":["00000000"]*8
}
FONT_8x8.update({
    "!": ["00010000","00010000","00010000","00010000","00010000","00000000","00010000","00000000"],
    "?": ["00111000","01000100","00000100","00001000","00010000","00000000","00010000","00000000"],
    "-": ["00000000","00000000","00000000","01111100","00000000","00000000","00000000","00000000"],
    "+": ["00000000","00010000","00010000","01111100","00010000","00010000","00000000","00000000"],
    "=": ["00000000","00000000","01111100","00000000","01111100","00000000","00000000","00000000"],
    "/": ["00000010","00000100","00001000","00010000","00100000","01000000","10000000","00000000"],
    "\\":["10000000","01000000","00100000","00010000","00001000","00000100","00000010","00000000"],
    "*": ["00000000","01000100","00101000","01111100","00101000","01000100","00000000","00000000"],
    "%": ["01100000","01100100","00001000","00010000","00100000","01001100","00001100","00000000"],
    "(": ["00001000","00010000","00100000","00100000","00100000","00010000","00001000","00000000"],
    ")": ["00100000","00010000","00001000","00001000","00001000","00010000","00100000","00000000"],
    "[": ["00111000","00100000","00100000","00100000","00100000","00100000","00111000","00000000"],
    "]": ["00111000","00001000","00001000","00001000","00001000","00001000","00111000","00000000"],
    "{": ["00001100","00010000","00010000","00100000","00010000","00010000","00001100","00000000"],
    "}": ["00110000","00001000","00001000","00000100","00001000","00001000","00110000","00000000"],
    "'": ["00010000","00010000","00010000","00000000","00000000","00000000","00000000","00000000"],
    "\"":["01000100","01000100","01000100","00000000","00000000","00000000","00000000","00000000"],
    ";": ["00000000","00000000","00011000","00011000","00000000","00011000","00011000","00001000"],
    "_": ["00000000","00000000","00000000","00000000","00000000","00000000","01111100","00000000"],
    "@": ["00111000","01000100","01011100","01101100","01101100","01000000","00111100","00000000"],
    "#": ["00010100","00010100","01111110","00010100","00010100","01111110","00010100","00010100"],
    "$": ["00010000","01111100","01010000","01111100","00010100","01111100","00010000","00000000"],
    "&": ["00110000","01001000","00110000","01101000","01010100","01001000","00110100","00000000"],
    "°": ["00110000","01001000","00110000","00000000","00000000","00000000","00000000","00000000"],
    "▶": ["00011000","00011100","00011110","00011111","00011110","00011100","00011000","00000000"],
    "■": ["00000000","01111110","01111110","01111110","01111110","01111110","00000000","00000000"],
    "□": ["00000000","01111110","01000010","01000010","01000010","01111110","00000000","00000000"],
    "☑": ["01111110","01000010","01011010","01011010","01000010","01111110","00000000","00000000"],
})
FONT_8x8.update({
    "↑": ["00010000","00010000","00111000","01010100","00010000","00010000","00010000","00000000"],
    "↓": ["00010000","00010000","00010000","00010000","01010100","00111000","00010000","00000000"],
    "←": ["00001000","00010000","00100000","01111100","00100000","00010000","00001000","00000000"],
    "→": ["00100000","00010000","00001000","01111100","00001000","00010000","00100000","00000000"],
    "↔": ["00001000","00010000","00101000","01111100","00101000","00010000","00001000","00000000"],
    "❤": ["00000000","01100110","11111111","11111111","01111110","00111100","00011000","00000000"],
    "♥": ["00000000","01100110","11111111","11111111","01111110","00111100","00011000","00000000"],
    "☺": ["00111100","01000010","10100101","10000001","10100101","10011001","01000010","00111100"],
    "☻": ["00111100","01111110","11111111","11111111","11111111","11111111","01111110","00111100"],
    "✓": ["00000000","00000010","00000110","00001100","11011000","11100000","01000000","00000000"],
    "✗": ["00000000","10000001","01000010","00100100","00011000","00100100","01000010","10000001"],
    "★": ["00010000","01010100","00111000","11111111","00111000","01010100","00010000","00000000"],
    "☆": ["00010000","01010100","00111000","01111100","00111000","01010100","00010000","00000000"],
    "⚡": ["00001100","00011000","01111110","00011000","00110000","01111110","00110000","00000000"],
    "☀": ["00010000","01010100","00111000","01111100","00111000","01010100","00010000","00000000"],
    "☁": ["00000000","00111000","01111100","11111110","01111100","00111000","00000000","00000000"],
})
FONT_8x8.update({
    "a": ["00000000","00000000","00111000","00000100","00111100","01000100","00111100","00000000"],
    "b": ["01000000","01000000","01111000","01000100","01000100","01000100","01111000","00000000"],
    "c": ["00000000","00000000","00111100","01000000","01000000","01000000","00111100","00000000"],
    "d": ["00000100","00000100","00111100","01000100","01000100","01000100","00111100","00000000"],
    "e": ["00000000","00000000","00111000","01000100","01111100","01000000","00111100","00000000"],
    "f": ["00011100","00100000","00100000","01111000","00100000","00100000","00100000","00000000"],
    "g": ["00000000","00000000","00111100","01000100","00111100","00000100","00111000","00000000"],
    "h": ["01000000","01000000","01111000","01000100","01000100","01000100","01000100","00000000"],
    "i": ["00010000","00000000","00110000","00010000","00010000","00010000","00111000","00000000"],
    "j": ["00001000","00000000","00011000","00001000","00001000","01001000","01001000","00110000"],
    "k": ["01000000","01000000","01001000","01010000","01100000","01010000","01001000","00000000"],
    "l": ["00110000","00010000","00010000","00010000","00010000","00010000","00111000","00000000"],
    "m": ["00000000","00000000","01101000","01010100","01010100","01010100","01000100","00000000"],
    "n": ["00000000","00000000","01111000","01000100","01000100","01000100","01000100","00000000"],
    "o": ["00000000","00000000","00111000","01000100","01000100","01000100","00111000","00000000"],
    "p": ["00000000","00000000","01111000","01000100","01111000","01000000","01000000","00000000"],
    "q": ["00000000","00000000","00111100","01000100","00111100","00000100","00000100","00000000"],
    "r": ["00000000","00000000","01011000","01100100","01000000","01000000","01000000","00000000"],
    "s": ["00000000","00000000","00111100","01000000","00111000","00000100","01111000","00000000"],
    "t": ["00100000","00100000","01111000","00100000","00100000","00100000","00011000","00000000"],
    "u": ["00000000","00000000","01000100","01000100","01000100","01001100","00110100","00000000"],
    "v": ["00000000","00000000","01000100","01000100","01000100","00101000","00010000","00000000"],
    "w": ["00000000","00000000","01000100","01000100","01010100","01010100","00101000","00000000"],
    "x": ["00000000","00000000","01000100","00101000","00010000","00101000","01000100","00000000"],
    "y": ["00000000","00000000","01000100","01000100","00111100","00000100","00111000","00000000"],
    "z": ["00000000","00000000","01111100","00001000","00010000","00100000","01111100","00000000"],
})

# =========================
# Text rendering
# =========================
def render_message(msg):
    cols = []
    for ch in msg:
        pattern = FONT_8x8.get(ch) or FONT_8x8.get(ch.upper(), FONT_8x8[" "])
        for x in range(8):
            col_bits = 0
            for y in range(8):
                if pattern[y][x] == "1":
                    col_bits |= 1 << y
            cols.append(col_bits)
        cols.append(0)
    return cols

def scroll_once(cols, color):
    total = len(cols)
    for offset in range(total + WIDTH):
        np.fill((0,0,0))
        for x in range(WIDTH):
            ci = offset + x - WIDTH
            if 0 <= ci < total:
                col = cols[ci]
                for y in range(8):
                    if col & (1<<y):
                        np[XY(x, (HEIGHT-1)-y)] = scale(color)
        np.write()
        time.sleep(SCROLL_SPEED)

def scroll_text(msg, color=(255,255,255)):
    cols = render_message(msg)
    scroll_once(cols, color)

# =========================
# Config storage
# =========================
CFG_FILE = "wifi.json"
DEFAULT_TITLE = "LED Matrix"

def load_cfg():
    try:
        with open(CFG_FILE, "r") as f:
            return ujson.loads(f.read())
    except:
        return {}

def save_cfg(cfg):
    with open(CFG_FILE, "w") as f:
        f.write(ujson.dumps(cfg))

# =========================
# Wi-Fi Station + AP Portal
# =========================
wlan = network.WLAN(network.STA_IF)
ap = network.WLAN(network.AP_IF)

def urlencode_simple(s):
    return s.replace(" ", "%20")

def geocode_city(city):
    """Return (lat, lon, tz) using Open-Meteo geocoding."""
    try:
        host = "geocoding-api.open-meteo.com"
        path = "/v1/search?name={}&count=1".format(urlencode_simple(city))
        addr = socket.getaddrinfo(host, 80)[0][-1]
        s = socket.socket(); s.settimeout(8); s.connect(addr)
        s.send(b"GET " + path.encode() + b" HTTP/1.1\r\nHost: " + host.encode() + b"\r\nConnection: close\r\n\r\n")
        resp = b""
        while True:
            chunk = s.recv(256)
            if not chunk: break
            resp += chunk
        try: s.close()
        except: pass
        i = resp.find(b"\r\n\r\n")
        if i == -1: return None
        body = resp[i+4:].strip()
        j0, j1 = body.find(b"{"), body.rfind(b"}")
        if j0 == -1 or j1 == -1: return None
        js = ujson.loads(body[j0:j1+1])
        results = js.get("results") or []
        if not results: return None
        r0 = results[0]
        lat = float(r0.get("latitude"))
        lon = float(r0.get("longitude"))
        tz = r0.get("timezone") or "Etc/UTC"
        return (lat, lon, tz)
    except Exception as e:
        print("Geocode failed:", e)
        return None

def _safe_close(sock):
    try: sock.close()
    except: pass

def _bind_listen_with_retry(addr, max_retries=10, delay=0.3):
    for _ in range(max_retries):
        try:
            s = socket.socket()
            try:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            except:
                pass
            s.bind(addr)
            s.listen(1)
            return s
        except OSError as e:
            _safe_close(s)
            if getattr(e, "errno", None) == 112:  # EADDRINUSE
                time.sleep(delay)
                continue
            raise
    raise OSError(112, "Port still busy after retries")

def start_config_portal():
    ap.active(True)
    ap.config(essid="led", authmode=network.AUTH_OPEN)
    addr = socket.getaddrinfo("0.0.0.0", 80)[0][-1]
    s = None
    try:
        s = _bind_listen_with_retry(addr, max_retries=10, delay=0.25)
    except OSError as e:
        print("Config portal bind error:", e)
        return

    s.settimeout(0.5)

    print("=== CONFIG MODE ===")
    print("AP portal on", ("0.0.0.0", 80))

    try:
        scroll_text("Join Wi-Fi: led   Open: 192.168.4.1")
    except:
        pass

    HTML = """\
HTTP/1.1 200 OK
Content-Type: text/html; charset=utf-8

<!DOCTYPE html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>LED Matrix Setup</title>
<style>body{font-family:Arial;margin:20px;}label{display:block;margin-top:8px}input{width:100%;padding:8px;margin-top:2px}button{margin-top:12px;padding:10px 14px;width:100%}</style>
</head><body>
<h2>LED Matrix – First-time Setup</h2>
<form action="/" method="get">
<label>Wi-Fi SSID</label><input name="ssid" placeholder="Your Wi-Fi">
<label>Password</label><input name="password" placeholder="Wi-Fi password">
<label>Device Title (optional)</label><input name="title" placeholder="LED Matrix">
<label>City (for local time & weather)</label><input name="city" placeholder="Toronto">
<button type="submit">Save & Connect</button>
</form>
</body></html>"""

    last_toggle = time.ticks_ms()
    show_first = True

    while True:
        now = time.ticks_ms()
        if time.ticks_diff(now, last_toggle) > 3000:
            if show_first:
                oled_msg("WiFi setup", "SSID", "led", "")
            else:
                oled_msg("Then to", "192.168.", "4.1", "")
            show_first = not show_first
            last_toggle = now

        try:
            cl, _ = s.accept()
        except OSError:
            continue

        try:
            cl.settimeout(3)
            req = cl.recv(1024)
            if not req:
                cl.close()
                continue
            try:
                first = req.decode().split("\r\n",1)[0]
            except:
                cl.close()
                continue
            path = first.split(" ")[1] if " " in first else "/"
            if path.startswith("/?"):
                qs = path[2:]
                params = {}
                for pair in qs.split("&"):
                    if "=" in pair:
                        k,v = pair.split("=",1)
                        params[k]=v.replace("+"," ").replace("%20"," ")
                ssid = params.get("ssid","").strip()
                pwd  = params.get("password","").strip()
                title= params.get("title","").strip() or DEFAULT_TITLE
                city = params.get("city","").strip()

                if ssid and pwd:
                    cfg = load_cfg()
                    cfg["ssid"]=ssid; cfg["password"]=pwd; cfg["title"]=title
                    if city: cfg["city"]=city
                    save_cfg(cfg)
                    cl.send("HTTP/1.1 200 OK\r\nContent-Type:text/plain\r\n\r\nSaved. Trying to connect...")
                    cl.close()
                    break
            cl.send(HTML); cl.close()
        except OSError:
            try: cl.close()
            except: pass
            continue

    _safe_close(s)
    ap.active(False)
    time.sleep(0.5)
    gc.collect()

def connect_wifi_from_cfg():
    cfg = load_cfg()
    ssid = cfg.get("ssid", "")
    pwd  = cfg.get("password", "")

    if not ssid:
        print("No SSID saved")
        return False

    wlan.active(True)
    time.sleep(0.5)

    try:
        wlan.disconnect()
    except:
        pass
    time.sleep(0.2)

    for attempt in range(1, 6):
        print("WiFi connect attempt", attempt, "to", ssid)
        try:
            wlan.connect(ssid, pwd)
        except Exception as e:
            print("connect() error:", e)

        for _ in range(24):
            if wlan.isconnected():
                print("WiFi connected:", wlan.ifconfig())
                return True

            st = wlan.status()
            if st < 0:
                print("WiFi status failure:", st)
                break

            time.sleep(0.25)

        try:
            wlan.disconnect()
        except:
            pass
        time.sleep(0.8)

    print("WiFi connect failed. Final status:", wlan.status())
    return False

# =========================
# Weather + Time by City
# =========================
LAT, LON, TZ = 43.7, -79.4, "America/Toronto"
_last_weather_fetch = 0
latest_weather = None
_last_ip_scrolled = False

def fetch_weather_now():
    global latest_weather, _last_weather_fetch
    if not wlan.isconnected():
        return
    try:
        host = "api.open-meteo.com"
        path = "/v1/forecast?latitude={}&longitude={}&current_weather=true".format(LAT, LON)
        addr = socket.getaddrinfo(host, 80)[0][-1]
        s = socket.socket(); s.settimeout(8); s.connect(addr)
        s.send(b"GET " + path.encode() + b" HTTP/1.1\r\nHost: "+host.encode()+b"\r\nConnection: close\r\n\r\n")
        resp=b""
        while True:
            chunk=s.recv(256)
            if not chunk: break
            resp+=chunk
        _safe_close(s)
        i=resp.find(b"\r\n\r\n")
        if i==-1: return
        body=resp[i+4:].strip()
        j0,j1=body.find(b"{"), body.rfind(b"}")
        if j0==-1 or j1==-1: return
        js=ujson.loads(body[j0:j1+1])
        cw=js.get("current_weather",{})
        temp=cw.get("temperature",0)
        wind=cw.get("windspeed",0)
        latest_weather="Temp {:.1f}C Wind {:.0f}km/h".format(temp, wind)
        _last_weather_fetch=time.time()
        print("Weather:", latest_weather)
    except Exception as e:
        print("Weather fetch failed:", e)

def geocode_if_needed_and_persist():
    global LAT, LON, TZ
    cfg = load_cfg()
    city = cfg.get("city")
    have_coords = ("lat" in cfg and "lon" in cfg)
    have_tz = ("tz" in cfg)
    if city and (not have_coords or not have_tz):
        r = geocode_city(city)
        if r:
            LAT, LON, TZ = r[0], r[1], r[2]
            cfg["lat"]=LAT; cfg["lon"]=LON; cfg["tz"]=TZ
            save_cfg(cfg)
            print("Geocoded:", city, "->", LAT, LON, TZ)
        else:
            print("Geocode failed, keeping defaults")
    else:
        LAT = cfg.get("lat", LAT)
        LON = cfg.get("lon", LON)
        TZ  = cfg.get("tz", TZ)

# --- NEW TIME SOURCE ---
# We keep your "city -> TZ" behavior, but we stop depending on WorldTimeAPI.
# NTP gives reliable UTC time; Open-Meteo gives the correct utc_offset_seconds for the timezone (DST-safe).
_last_offset_fetch_ms = 0
_cached_utc_offset_seconds = 0

def fetch_utc_offset_seconds():
    """Fetch utc_offset_seconds for the current TZ using Open-Meteo. DST-safe."""
    try:
        host = "api.open-meteo.com"
        # timezone=TZ makes Open-Meteo compute the correct offset now (including DST)
        path = "/v1/forecast?latitude={}&longitude={}&current_weather=true&timezone={}".format(LAT, LON, urlencode_simple(TZ))
        addr = socket.getaddrinfo(host, 80)[0][-1]
        s = socket.socket(); s.settimeout(8); s.connect(addr)
        s.send(b"GET " + path.encode() + b" HTTP/1.1\r\nHost: "+host.encode()+b"\r\nConnection: close\r\n\r\n")
        resp=b""
        while True:
            c=s.recv(256)
            if not c: break
            resp+=c
        _safe_close(s)
        i=resp.find(b"\r\n\r\n")
        if i==-1: return None
        body=resp[i+4:].strip()
        j0,j1=body.find(b"{"), body.rfind(b"}")
        if j0==-1 or j1==-1: return None
        js=ujson.loads(body[j0:j1+1])
        # Open-Meteo returns utc_offset_seconds at top-level
        off = js.get("utc_offset_seconds", None)
        if off is None:
            return None
        return int(off)
    except Exception as e:
        print("Offset fetch failed:", e)
        return None

def fetch_time_info():
    """
    Returns (base_uni, utc_offset_seconds) using:
      - NTP for base time (reliable)
      - Open-Meteo for timezone/DST offset (city-based, reliable)
    base_uni is in MicroPython's epoch units (whatever time.time() uses on your build),
    and we use time.gmtime(base_uni + offset) so it won't crash due to epoch mismatch.
    """
    global _last_offset_fetch_ms, _cached_utc_offset_seconds
    try:
        # 1) sync clock using NTP (UTC)
        ntptime.settime()

        base_uni = time.time()

        # 2) refresh offset at most every 6 hours
        now_ms = time.ticks_ms()
        if time.ticks_diff(now_ms, _last_offset_fetch_ms) > 6 * 3600 * 1000 or _last_offset_fetch_ms == 0:
            off = fetch_utc_offset_seconds()
            if off is not None:
                _cached_utc_offset_seconds = off
                _last_offset_fetch_ms = now_ms
                print("UTC offset seconds:", _cached_utc_offset_seconds, "TZ:", TZ)
            else:
                print("UTC offset fetch returned None; using cached:", _cached_utc_offset_seconds)

        return (base_uni, _cached_utc_offset_seconds)
    except Exception as e:
        print("Time fetch failed:", e)
        return None

def localtime_from_unixtime(base_uni, off_sec):
    # Use gmtime() so we stay consistent and avoid epoch conversion crashes.
    return time.gmtime(base_uni + off_sec)

# =========================
# Animations (ALL)
# =========================
def fireworks_animation():
    clear()
    for _ in range(5):
        x = urandom.getrandbits(3) % WIDTH
        y = urandom.getrandbits(3) % HEIGHT
        color = random_color()
        set_pixel(x, y, color)
        np.write()
        time.sleep(0.05)
        for r in range(1, 1 + max(WIDTH, HEIGHT)//2):
            for dx in range(-r, r+1):
                for dy in range(-r, r+1):
                    if abs(dx)+abs(dy) == r:
                        set_pixel(x+dx, y+dy, color)
            np.write()
            time.sleep(0.05)
        clear()

def explosion_animation():
    cx, cy = (WIDTH // 2) - 1, (HEIGHT // 2) - 1
    color = random_color()
    for r in range(1, max(WIDTH, HEIGHT)):
        for dx in range(-r, r+1):
            for dy in range(-r, r+1):
                if abs(dx) == r or abs(dy) == r:
                    set_pixel(cx+dx, cy+dy, color)
        np.write()
        time.sleep(0.08)
    clear()

def random_dir():
    return 1 if urandom.getrandbits(1) else -1

def bouncing_ball(speed=.05):
    x, y = (WIDTH // 2), (HEIGHT // 2)
    dx, dy = 1, 1
    color = random_color()
    while current_mode == "ball":
        np.fill((0,0,0))
        np[XY(x, y)] = scale(color)
        np.write()
        time.sleep(speed)
        x += dx; y += dy; bounced = False
        if x < 0:
            x = 0; dx = random_dir(); bounced = True
        elif x >= WIDTH:
            x = WIDTH - 1; dx = random_dir(); bounced = True
        if y < 0:
            y = 0; dy = random_dir(); bounced = True
        elif y >= HEIGHT:
            y = HEIGHT - 1; dy = random_dir(); bounced = True
        if bounced:
            color = random_color()

def sine_wave_animation(speed=0.1):
    phase = 0
    while current_mode == "sinewave":
        np.fill((0,0,0))
        color = random_color()
        for x in range(WIDTH):
            y = int((math.sin((x + phase) * 0.8) + 1) * (HEIGHT - 1) / 2)
            np[XY(x, y)] = scale(color)
        np.write()
        time.sleep(speed)
        phase += 1

def matrix_rain_animation(speed=0.06, spawn_prob=0.35, fade=0.72, head_brightness=1.0, trail_brightness=0.5):
    heads = []
    fb_fill((0, 0, 0))
    while current_mode == "matrix":
        if urandom.getrandbits(8) < int(spawn_prob * 255):
            heads.append([urandom.getrandbits(3) % WIDTH, HEIGHT - 1])
        fb_fade(fade)
        new_heads = []
        for x, y in heads:
            fb_set(x, y, (0, int(255 * head_brightness), 0))
            if y - 1 >= 0:
                r, g, b = fb[y - 1][x]
                g = max(g, int(255 * trail_brightness))
                fb_set(x, y - 1, (0, g, 0))
            y -= 1
            if y >= 0:
                new_heads.append([x, y])
        heads = new_heads
        fb_render()
        time.sleep(speed)

def radar_sweep_animation(speed=0.03, fade=0.80):
    fb_fill((0, 0, 0))
    theta = 0.0
    while current_mode == "radar":
        fb_fade(fade)
        cx, cy = (WIDTH - 1) / 2.0, (HEIGHT - 1) / 2.0
        max_r = max(WIDTH, HEIGHT)
        for r in range(0, max_r):
            x = int(cx + r * math.cos(theta))
            y = int(cy + r * math.sin(theta))
            if 0 <= x < WIDTH and 0 <= y < HEIGHT:
                fb_set(x, y, (30, 200, 200))
        fb_render()
        theta += 0.18
        if theta > math.tau:
            theta -= math.tau
        time.sleep(speed)

def plasma_animation(speed=0.06):
    t = 0.0
    while current_mode == "plasma":
        for y in range(HEIGHT):
            for x in range(WIDTH):
                v = (
                    math.sin(x * 0.6 + t) +
                    math.sin(y * 0.6 + t * 1.3) +
                    math.sin((x * 0.4 + y * 0.4 + t * 0.7))
                ) / 3.0
                v = (v + 1.0) / 2.0
                r = int(255 * v)
                g = int(255 * (1.0 - v))
                b = int(255 * (0.5 + 0.5 * math.sin(6.283 * (v + 0.25))))
                fb_set(x, y, (r, g, b))
        fb_render()
        t += 0.12
        time.sleep(speed)

def fire_lava_animation(speed=0.04, cooling=0.25, sparking=0.35):
    heat = [[0 for _ in range(WIDTH)] for _ in range(HEIGHT)]
    while current_mode == "fire":
        for x in range(WIDTH):
            for y in range(HEIGHT):
                cool = urandom.getrandbits(8) / 255 * cooling * 255
                heat[y][x] = max(0, heat[y][x] - int(cool))
        for x in range(WIDTH):
            for y in range(HEIGHT - 1, 1, -1):
                heat[y][x] = (heat[y-1][x] + heat[y-2][x] + heat[y-2][x]) // 3
        for x in range(WIDTH):
            if urandom.getrandbits(8) < int(sparking * 255):
                heat[0][x] = min(255, heat[0][x] + urandom.getrandbits(7) + 128)
        for y in range(HEIGHT):
            for x in range(WIDTH):
                t = heat[y][x]
                r = min(255, t)
                g = min(255, max(0, t - 80))
                b = max(0, int(t * 0.2))
                fb_set(x, y, (r, g, b))
        fb_render()
        time.sleep(speed)

def hsv_to_rgb(h, s, v):
    h = h % 1.0
    i = int(h * 6)
    f = h * 6 - i
    p = int(255 * v * (1 - s))
    q = int(255 * v * (1 - f * s))
    t = int(255 * v * (1 - (1 - f) * s))
    v255 = int(255 * v)
    i = i % 6
    if i == 0: return (v255, t, p)
    if i == 1: return (q, v255, p)
    if i == 2: return (p, v255, t)
    if i == 3: return (p, q, v255)
    if i == 4: return (t, p, v255)
    return (v255, p, q)

def aurora_animation(speed=0.05):
    t = 0.0
    while current_mode == "aurora":
        for y in range(HEIGHT):
            for x in range(WIDTH):
                w1 = math.sin((x * 0.45) + t)
                w2 = math.sin((y * 0.30) + t * 0.8)
                w3 = math.sin((x * 0.35 + y * 0.20) + t * 1.3)
                m = (w1 + w2 + w3) / 3.0
                h = 0.45 + 0.25 * m
                s = 0.6 + 0.35 * ((w2 + 1) / 2)
                v = 0.35 + 0.55 * ((w1 + 1) / 2)
                fb_set(x, y, hsv_to_rgb(h, s, v))
        fb_render()
        t += 0.05
        time.sleep(speed)

def starfield_animation(speed=0.06, spawn_prob=0.15, fade=0.8):
    fb_fill((0, 0, 0))
    while current_mode == "starfield":
        fb_fade(fade)
        if urandom.getrandbits(8) < int(spawn_prob * 255):
            x = urandom.getrandbits(3) % WIDTH
            y = urandom.getrandbits(3) % HEIGHT
            c = random_color()
            fb_set(x, y, (max(150, c[0]), max(150, c[1]), max(150, c[2])))
        fb_render()
        time.sleep(speed)

def clock_animation():
    gc.collect()

    tinfo = fetch_time_info()
    if tinfo:
        base_uni, base_off = tinfo
    else:
        base_uni, base_off = time.time(), 0

    start_ms = time.ticks_ms()
    last_sync_ms = start_ms

    while current_mode == "clock":
        # Re-sync every hour
        if time.ticks_diff(time.ticks_ms(), last_sync_ms) > 3600 * 1000:
            tinfo = fetch_time_info()
            if tinfo:
                base_uni, base_off = tinfo
                start_ms = time.ticks_ms()
                last_sync_ms = start_ms

        elapsed = time.ticks_diff(time.ticks_ms(), start_ms) // 1000
        uni_now = base_uni + elapsed
        tm = localtime_from_unixtime(uni_now, base_off)

        msg = "{:02d}:{:02d}".format(tm[3], tm[4])
        scroll_text(msg)
        gc.collect()

def weather_animation():
    gc.collect()
    while current_mode == "weather":
        if latest_weather:
            line = latest_weather
        else:
            line = "Loading weather..."
        scroll_text(line)
        time.sleep(0.3)
        gc.collect()

# =========================
# HTTP Server + Web UI
# =========================
def urldecode(s):
    out=[]; i=0; L=len(s)
    while i<L:
        c=s[i]
        if c=='+': out.append(' ')
        elif c=='%' and i+2<L:
            try:
                out.append(chr(int(s[i+1:i+3],16))); i+=2
            except:
                out.append('%')
        else:
            out.append(c)
        i+=1
    return ''.join(out)

def start_http_server(update_message_callback, stop_callback, set_mode_callback, page_title):
    def send_page(cl):
        bri = int(BRIGHTNESS * 100)
        cl.send("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n\r\n")
        cl.send("<!DOCTYPE html><html><head>")
        cl.send("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">")
        cl.send("<title>"); cl.send(page_title); cl.send("</title>")
        cl.send("<style>")
        cl.send("body{font-family:Arial,sans-serif;background:#f2f2f2;display:flex;")
        cl.send("justify-content:center;align-items:center;height:100vh;margin:0;}")
        cl.send(".container{background:white;padding:20px;border-radius:12px;")
        cl.send("box-shadow:0 4px 15px rgba(0,0,0,0.1);max-width:480px;width:95%;text-align:center;}")
        cl.send("h1{font-size:20px;margin-bottom:10px;}")
        cl.send("input[type=text]{width:100%;padding:10px;font-size:16px;margin-bottom:10px;")
        cl.send("border:1px solid #ccc;border-radius:8px;box-sizing:border-box;}")
        cl.send("input[type=range]{width:100%;}")
        cl.send("button{width:100%;padding:10px;font-size:16px;border:none;border-radius:8px;")
        cl.send("cursor:pointer;margin-bottom:8px;}")
        cl.send(".send-btn{background-color:#0078d7;color:white;}")
        cl.send(".stop-btn{background-color:#d9534f;color:white;}")
        cl.send(".mode-btn{background-color:#555;color:white;}")
        cl.send(".mode-btn:hover{background-color:#333;}")
        cl.send(".row{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px;}")
        cl.send(".card{background:#fafafa;border:1px solid #eee;padding:10px;border-radius:8px;margin-top:8px;}")
        cl.send("</style></head><body>")

        cl.send("<div class=\"container\"><h1>")
        cl.send(page_title)
        cl.send("</h1>")

        cl.send("<div class=\"card\">")
        cl.send("<form action=\"/\" method=\"get\">")
        cl.send("<input type=\"text\" name=\"msg\" placeholder=\"Type message here\">")
        cl.send("<button class=\"send-btn\" type=\"submit\">Send Text</button>")
        cl.send("</form></div>")

        cl.send("<div class=\"card\">")
        cl.send("<label for=\"bri\">💡 Brightness: <b>")
        cl.send(str(bri))
        cl.send("%</b></label>")
        cl.send("<form action=\"/\" method=\"get\">")
        cl.send("<input id=\"bri\" type=\"range\" name=\"brightness\" min=\"1\" max=\"100\" value=\"")
        cl.send(str(bri))
        cl.send("\" oninput=\"bval.value=this.value\">")
        cl.send("<div>Set to: <output id=\"bval\">")
        cl.send(str(bri))
        cl.send("</output>%</div>")
        cl.send("<button class=\"mode-btn\" type=\"submit\">Apply Brightness</button>")
        cl.send("</form></div>")

        def mode_btn(val, label):
            cl.send("<form action=\"/\" method=\"get\">")
            cl.send("<input type=\"hidden\" name=\"mode\" value=\"")
            cl.send(val)
            cl.send("\"><button class=\"mode-btn\">")
            cl.send(label)
            cl.send("</button></form>")

        cl.send("<div class=\"row\">")
        mode_btn("matrix", "🌧 Matrix")
        mode_btn("radar", "🧭 Radar")
        mode_btn("plasma", "🌈 Plasma")
        mode_btn("sinewave", "🌊 Sine Wave")
        mode_btn("fireworks", "🎆 Fireworks")
        mode_btn("explosion", "💥 Explosion")
        mode_btn("ball", "🟠 Ball")
        mode_btn("clock", "🕒 Clock")
        mode_btn("fire", "🔥 Fire")
        mode_btn("aurora", "🌌 Aurora")
        mode_btn("starfield", "✨ Starfield")
        mode_btn("weather", "☁ Weather")
        cl.send("</div>")

        cl.send("<div class=\"card\">")
        cl.send("<form action=\"/\" method=\"get\">")
        cl.send("<input type=\"hidden\" name=\"stop\" value=\"1\">")
        cl.send("<button class=\"stop-btn\" type=\"submit\">🛑 Stop</button>")
        cl.send("</form></div>")

        cl.send("</div></body></html>")

    addr = socket.getaddrinfo('0.0.0.0', 80)[0][-1]
    try:
        s = _bind_listen_with_retry(addr, max_retries=10, delay=0.25)
    except OSError as e:
        print("⚠️ Port 80 bind failed:", e)
        return
    s.settimeout(30)
    print("HTTP server listening on 80")

    while True:
        try:
            cl, addr = s.accept()
            cl.settimeout(3)
            req = cl.recv(1024)
            if not req:
                cl.close()
                gc.collect()
                continue
            try:
                first = req.decode().split("\r\n", 1)[0]
            except:
                cl.close()
                gc.collect()
                continue

            parts = first.split(" ")
            path = parts[1] if len(parts) > 1 else "/"

            if path.startswith("/?brightness="):
                val = path[len("/?brightness="):]
                amp = val.find("&")
                if amp != -1:
                    val = val[:amp]
                try:
                    pct = int(val)
                    pct = max(1, min(100, pct))
                    global BRIGHTNESS
                    BRIGHTNESS = pct / 100.0
                    print("Brightness:", pct, "%")
                except:
                    pass
                send_page(cl)
                cl.close()
                gc.collect()
                continue

            if path.startswith("/?stop="):
                stop_callback()
                cl.send("HTTP/1.1 303 See Other\r\nLocation: /\r\n\r\n")
                cl.close()
                gc.collect()
                continue

            elif path.startswith("/?msg="):
                new_msg = path[6:]
                amp = new_msg.find("&")
                if amp != -1:
                    new_msg = new_msg[:amp]
                update_message_callback(urldecode(new_msg))
                cl.send("HTTP/1.1 303 See Other\r\nLocation: /\r\n\r\n")
                cl.close()
                gc.collect()
                continue

            elif path.startswith("/?mode="):
                mode = path[7:]
                amp = mode.find("&")
                if amp != -1:
                    mode = mode[:amp]
                set_mode_callback(urldecode(mode))
                cl.send("HTTP/1.1 303 See Other\r\nLocation: /\r\n\r\n")
                cl.close()
                gc.collect()
                continue

            elif path.startswith("/json"):
                body = '{{"mode":"{}","msg":"{}","ip":"{}","connected":{},"brightness":{}}}'.format(
                    current_mode,
                    current_message.replace('"', "'"),
                    ip_address,
                    "true" if wlan.isconnected() else "false",
                    int(BRIGHTNESS * 100)
                )
                cl.send("HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n")
                cl.send(body)
                cl.close()
                gc.collect()
                continue

            send_page(cl)
            cl.close()
            gc.collect()

        except OSError:
            gc.collect()
            pass

# =========================
# Main Program
# =========================
current_message = ""
current_mode = "idle"
ip_address = "0.0.0.0"

def update_message(new_msg):
    global current_message, current_mode
    current_message = new_msg; current_mode = "text"

def stop_message():
    global current_message, current_mode
    current_message = ""; current_mode = "idle"; clear()

def set_mode(new_mode):
    global current_mode, current_message
    current_mode = new_mode; current_message = ""

def weather_thread():
    global _last_weather_fetch, latest_weather
    last_ms = time.ticks_ms()
    fetched_once_this_connection = False

    while True:
        try:
            if wlan.isconnected():
                if not fetched_once_this_connection or latest_weather is None:
                    fetch_weather_now()
                    fetched_once_this_connection = True
                    last_ms = time.ticks_ms()

                if time.ticks_diff(time.ticks_ms(), last_ms) > 600_000:
                    fetch_weather_now()
                    last_ms = time.ticks_ms()
            else:
                fetched_once_this_connection = False
        except Exception as e:
            print("weather_thread error:", e)

        time.sleep(5)
        gc.collect()

def oled_status_thread():
    while True:
        if wlan.isconnected():
            ip = wlan.ifconfig()[0]
            try:
                rssi = wlan.status('rssi')
            except:
                rssi = None

            l2, l3, l4 = format_ip_three_lines(ip)
            oled_msg("IP:", l2, l3, l4)
            for _ in range(4):
                if not wlan.isconnected(): break
                time.sleep(0.5)

            if wlan.isconnected():
                oled_msg("RSSI:", "{} dBm".format(rssi if rssi is not None else 0), rate_signal(rssi))
                for _ in range(4):
                    if not wlan.isconnected(): break
                    time.sleep(0.5)
        else:
            time.sleep(0.5)

cfg = load_cfg()
raw_title = cfg.get("title", DEFAULT_TITLE)
city_for_title = cfg.get("city", "").strip()
page_title = raw_title if not city_for_title else "{} — {}".format(raw_title, city_for_title)

connected = connect_wifi_from_cfg()

while not connected:
    start_config_portal()
    cfg = load_cfg()
    raw_title = cfg.get("title", DEFAULT_TITLE)
    city_for_title = cfg.get("city", "").strip()
    page_title = raw_title if not city_for_title else "{} — {}".format(raw_title, city_for_title)
    connected = connect_wifi_from_cfg()

if connected:
    ip_address = wlan.ifconfig()[0]
    geocode_if_needed_and_persist()
    print("\nWeb UI: http://{}/\n".format(ip_address))
    if not _last_ip_scrolled:
        scroll_text(ip_address); _last_ip_scrolled = True

    try:
        rssi0 = wlan.status('rssi')
    except:
        rssi0 = None

    l2, l3, l4 = format_ip_three_lines(ip_address)
    oled_msg("IP:", l2, l3, l4)
    time.sleep(2)
    oled_msg("RSSI:", "{} dBm".format(rssi0 if rssi0 is not None else 0), rate_signal(rssi0))
    time.sleep(2)

_thread.start_new_thread(start_http_server, (update_message, stop_message, set_mode, page_title))
_thread.start_new_thread(weather_thread, ())
_thread.start_new_thread(oled_status_thread, ())

def render_message_once(msg):
    cols = render_message(msg)
    scroll_once(cols, random_color())

while True:
    if current_mode == "idle":
        time.sleep(0.5)
    elif current_mode == "text":
        if current_message.strip():
            render_message_once(current_message)
        else:
            time.sleep(0.1)
    elif current_mode == "fireworks":
        fireworks_animation()
    elif current_mode == "explosion":
        explosion_animation()
    elif current_mode == "ball":
        bouncing_ball(.02)
    elif current_mode == "sinewave":
        sine_wave_animation(.10)
    elif current_mode == "matrix":
        matrix_rain_animation()
    elif current_mode == "radar":
        radar_sweep_animation()
    elif current_mode == "plasma":
        plasma_animation()
    elif current_mode == "clock":
        clock_animation()
    elif current_mode == "fire":
        fire_lava_animation()
    elif current_mode == "aurora":
        aurora_animation()
    elif current_mode == "starfield":
        starfield_animation()
    elif current_mode == "weather":
        weather_animation()
    else:
        time.sleep(0.1)